/** PixelCargo: 18-city county-neighbour segment composer. Does NOT invent geometry or reverse roads.
 * Import a JSON array of 86 directional graph edges. Validate independently before activating. */
export type LonLat = readonly [number, number];
export interface CountyEdge { id:string; linkId:string; fromCityId:string; toCityId:string; meters:number; seconds:number; geometry:LonLat[] }
export interface CompositeCountyRoute { id:string; fromCityId:string; toCityId:string; meters:number; seconds:number; geometry:LonLat[]; viaCityIds:string[]; segmentIds:string[] }
export function makeCountyRouter(edges:readonly CountyEdge[]){
 const from=new Map<string, CountyEdge[]>();
 for(const e of edges){ if(e.meters<=0||e.seconds<=0||e.geometry.length<2)throw Error(`Invalid edge ${e.id}`);const arr=from.get(e.fromCityId)||[];arr.push(e);from.set(e.fromCityId,arr); }
 return function routeBetween(start:string,goal:string):CompositeCountyRoute|null {
  if(start===goal)return null;
  const distance=new Map<string,number>([[start,0]]),previous=new Map<string,CountyEdge>(),visited=new Set<string>();
  while(true){let city:string|undefined,lowest=Infinity;
   for(const [id,d] of distance)if(!visited.has(id)&&d<lowest){city=id;lowest=d}
   if(!city)break;if(city===goal)break;visited.add(city);
   for(const edge of from.get(city)||[]){const cost=lowest+edge.meters;
    if(cost<(distance.get(edge.toCityId)??Infinity)){distance.set(edge.toCityId,cost);previous.set(edge.toCityId,edge)}
   }
  }
  if(!distance.has(goal))return null;
  let here=goal;const segments:CountyEdge[]=[];
  while(here!==start){const edge=previous.get(here);if(!edge)throw Error('Disconnected reconstruction');segments.unshift(edge);here=edge.fromCityId;}
  const geometry:LonLat[]=[];let meters=0,seconds=0;
  for(const edge of segments){
   if(geometry.length){const p=geometry[geometry.length-1],q=edge.geometry[0];if(p[0]!==q[0]||p[1]!==q[1])throw Error(`Disjoint OSM endpoints at ${edge.id}`);geometry.push(...edge.geometry.slice(1));}
   else geometry.push(...edge.geometry);
   meters+=edge.meters; seconds+=edge.seconds;
  }
  return {id:`county:${segments.map(s=>s.id).join('+')}`,fromCityId:start,toCityId:goal,meters,seconds,geometry,
   viaCityIds:[start,...segments.map(s=>s.toCityId)],segmentIds:segments.map(s=>s.id)};
 }
}
