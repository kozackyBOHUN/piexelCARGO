import json, pathlib, math, heapq
p=pathlib.Path(__file__).parent
a=json.loads((p/'adjacency_routes_ready_candidates.json').read_text())
c=json.loads((p/'cities_19_with_snap_override.json').read_text()); s={x['cityId'] for x in c if x['name']!='Gorlice'}
assert len(c)==19 and len(a)==86 and len(s)==18
x={(t['fromCityId'],t['toCityId']):t for t in a}; assert len(x)==86
froms={z:[] for z in s}
for t in a:
 assert t['fromCityId'] in s and t['toCityId'] in s and t['meters']>0 and t['seconds']>0 and len(t['geometry'])>=2
 assert all(len(v)==2 and all(math.isfinite(vv) for vv in v) for v in t['geometry'])
 froms[t['fromCityId']].append(t['toCityId'])
for start in s:
 found={start}; queue=[start]
 for v in queue:
  for dest in froms[v]:
   if dest not in found:found.add(dest);queue.append(dest)
 assert found==s,(start,len(found))
print('PASS: 19 city records, 18 connected city anchors, 86 directed segments, 306 directed origin-destination pairs. OSM turn/audit certification separate.')
