#!/usr/bin/env python3
"""Fast, OFFLINE integrity-only check. Not an OSM legal-routing audit."""
import json, pathlib, hashlib, collections
p=pathlib.Path(__file__).resolve().parents[1]
rd=lambda n:json.loads((p/n).read_text(encoding='utf8'))
manifest=rd('manifest.json'); ids=rd('data/old_08_approved_ids.json')
old=rd('data/old_08_approved_from_source.json')
new=rd('data/new_09_approved_links_from_source.json')
reject=rd('data/new_09_rejected_links_with_geometry.json')
gor=rd('data/gorlice_35_unverified_candidate_geometries.json')
prio=rd('data/gorlice_four_priority_candidates.json')
edges=rd('data/numbered_connections_45_status_09.json')
cities=rd('data/cities_19.json')['cities']
assert len(cities)==19 and len({x['cityId'] for x in cities})==19
assert len(ids['reportedCertifiedRouteIds'])==135
assert len(old)==134 and ids['missingInArchive']==['464cc1df']
assert len({(x['fromCityId'],x['toCityId']) for x in old})==134
assert len(new)==75 and len({x['id'] for x in new})==75
assert len(reject)==11 and len({x['id'] for x in reject})==11
assert not(set(x['id'] for x in new)&set(x['id'] for x in reject))
assert len(gor)==35 and len(prio)==4
assert len(edges)==45 and [x['number'] for x in edges]==list(range(1,46))
assert sum(x['status']=='both' for x in edges)==34
assert sum(x['status']=='one_direction' for x in edges)==7
assert sum(x['status']=='absent' for x in edges)==4
for route in [*old,*new,*reject,*gor]:
 assert route['geometry'] and route['meters']>0 and route['seconds']>0
 assert len(route['geometry'][0])==2
print('PASS bundle inventory: 19 cities, 45 numbered links, 134 archived/135 repository-certified 08, 75 approved 09, 11 rejected 09, 35 Gorlice candidates, 4 priority.')
print('IMPORTANT: Gorlice paths are NOT independently certified; full 342 cannot be asserted.')
